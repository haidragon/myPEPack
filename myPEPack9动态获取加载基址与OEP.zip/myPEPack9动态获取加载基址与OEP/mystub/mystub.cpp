// mystub.cpp : ���� DLL Ӧ�ó���ĵ���������
//
//CreateWindow         User32.dll
//GetModuleHandle      Kernel32.dll
//ShowWindow           User32.dll
//GetMessage           User32.dll
//RegisterClass        User32.dll
//DispatchMessage      User32.dll
//WindowProc    ֱ����
//PostQuitMessage      User32.dll
//DefWindowProc        User32.dll
//UpdateWindow         User32.dll
#include "stdafx.h"
#include "mystub.h"
//�ϲ���
#pragma comment(linker, "/merge:.data=.text") 
#pragma comment(linker, "/merge:.rdata=.text")
#pragma comment(linker, "/section:.text,RWE")
typedef int (WINAPI *LPMESSAGEBOX)(HWND, LPCTSTR, LPCTSTR, UINT); //MessageBoxW
typedef DWORD(WINAPI *LPGETPROCADDRESS)(HMODULE, LPCSTR);         // GetProcAddress
typedef HMODULE(WINAPI *LPLOADLIBRARYEX)(LPCTSTR, HANDLE, DWORD); // LoadLibaryEx
typedef HMODULE(WINAPI *GETModuleHandle)(
	_In_opt_ LPCTSTR lpModuleName
	);
typedef BOOL(WINAPI* SHOWWINDOW)(
	_In_ HWND hWnd,
	_In_ int  nCmdShow
	);
typedef BOOL(WINAPI* GteMessage)(
	_Out_    LPMSG lpMsg,
	_In_opt_ HWND  hWnd,
	_In_     UINT  wMsgFilterMin,
	_In_     UINT  wMsgFilterMax
	);
typedef LRESULT(WINAPI* DISpatchMessage)(
	_In_ const MSG *lpmsg
	);
typedef ATOM(WINAPI* REGisterClass)(
	_In_ const WNDCLASS *lpWndClass
	);
typedef HWND(WINAPI *CREateWindowEx)(
	_In_     DWORD     dwExStyle,
	_In_opt_ LPCTSTR   lpClassName,
	_In_opt_ LPCTSTR   lpWindowName,
	_In_     DWORD     dwStyle,
	_In_     int       x,
	_In_     int       y,
	_In_     int       nWidth,
	_In_     int       nHeight,
	_In_opt_ HWND      hWndParent,
	_In_opt_ HMENU     hMenu,
	_In_opt_ HINSTANCE hInstance,
	_In_opt_ LPVOID    lpParam
	);
typedef VOID(WINAPI* POSTQuitMessage)(
	_In_ int nExitCode
	);
typedef LRESULT(WINAPI* DEFWindowProc)(
	_In_ HWND   hWnd,
	_In_ UINT   Msg,
	_In_ WPARAM wParam,
	_In_ LPARAM lParam
	);
typedef BOOL(*UPDateWindow)(
	_In_ HWND hWnd
	);
typedef int (WINAPI* GETWindowText)(
	_In_  HWND   hWnd,
	_Out_ LPTSTR lpString,
	_In_  int    nMaxCount
	);
typedef int (WINAPI* GETWindowTextLength)(
	_In_ HWND hWnd
	);
typedef HWND(WINAPI* GETDlgItem)(
	_In_opt_ HWND hDlg,
	_In_     int  nIDDlgItem
	);
typedef BOOL( WINAPI* SETWindowText)(
	_In_     HWND    hWnd,
	_In_opt_ LPCTSTR lpString
);
typedef BOOL(WINAPI* TRanslateMessage)(
	_In_ const MSG *lpMsg
	);
wchar_t g_wcbuf100[100] = { 0 };
wchar_t g_MIMA100[100] = L"haidragon";
wchar_t wStrtext[100]  = L"����������";
/////////////////////////////////////////////////////////////
//��ʼ��
LPGETPROCADDRESS    g_funGetProcAddress = nullptr;
LPLOADLIBRARYEX     g_funLoadLibraryEx = nullptr;
HMODULE             hModuleKernel32 = nullptr;
HMODULE             hModuleUser32 = nullptr;
GETModuleHandle     g_funGetModuleHandle = nullptr;
LPMESSAGEBOX        g_funMessageBox = nullptr;
CREateWindowEx      g_funCreateWindowEx = nullptr;
POSTQuitMessage     g_funPostQuitMessage = nullptr;
DEFWindowProc       g_funDefWindowProc = nullptr;
GteMessage          g_funGetMessage = nullptr;
REGisterClass       g_funRegisterClass = nullptr;
SHOWWINDOW          g_funShowWindow = nullptr;
UPDateWindow        g_funUpdateWindow = nullptr;
DISpatchMessage     g_funDispatchMessage = nullptr;
GETWindowText       g_funGetWindowText = nullptr;
GETWindowTextLength g_funGetWindowTextLength = nullptr;
GETDlgItem          g_funGetDlgItem = nullptr;
SETWindowText       g_funSetWindowText = nullptr;
TRanslateMessage    g_funTranslateMessage = nullptr;

DWORD g_dwImageBase;
DWORD g_oep;
void start();
PACKINFO g_PackInfo = { (DWORD)start };
//��ȡkernel32ģ����ػ�ַ
DWORD GetKernel32Base()
{
	DWORD dwKernel32Addr = 0;
	__asm
	{
		push eax
		mov eax, dword ptr fs : [0x30] // eax = PEB�ĵ�ַ
		mov eax, [eax + 0x0C]          // eax = ָ��PEB_LDR_DATA�ṹ��ָ��
		mov eax, [eax + 0x1C]          // eax = ģ���ʼ��������ͷָ��InInitializationOrderModuleList
		mov eax, [eax]               // eax = �б��еĵڶ�����Ŀ
		mov eax, [eax + 0x08]          // eax = ��ȡ����Kernel32.dll��ַ��Win7�»�ȡ����KernelBase.dll�Ļ�ַ��
		mov dwKernel32Addr, eax
		pop eax
	}

	return dwKernel32Addr;
}
//��ȡGetProcAddress�Ļ�ַ
DWORD GetGPAFunAddr()
{
	DWORD dwAddrBase = GetKernel32Base();

	// 1. ��ȡDOSͷ��NTͷ
	PIMAGE_DOS_HEADER pDos_Header;
	PIMAGE_NT_HEADERS pNt_Header;
	pDos_Header = (PIMAGE_DOS_HEADER)dwAddrBase;
	pNt_Header = (PIMAGE_NT_HEADERS)(dwAddrBase + pDos_Header->e_lfanew);

	// 2. ��ȡ��������
	PIMAGE_DATA_DIRECTORY   pDataDir;
	PIMAGE_EXPORT_DIRECTORY pExport;
	pDataDir = pNt_Header->OptionalHeader.DataDirectory;
	pDataDir = &pDataDir[IMAGE_DIRECTORY_ENTRY_EXPORT];
	pExport = (PIMAGE_EXPORT_DIRECTORY)(dwAddrBase + pDataDir->VirtualAddress);

	// 3����ȡ�������ı�Ҫ��Ϣ
	DWORD dwModOffset = pExport->Name;                                  // ģ�������
	DWORD dwFunCount = pExport->NumberOfFunctions;                      // ��������������
	DWORD dwNameCount = pExport->NumberOfNames;                         // �������Ƶ�����

	PDWORD pEAT = (PDWORD)(dwAddrBase + pExport->AddressOfFunctions);   // ��ȡ��ַ����RVA
	PDWORD pENT = (PDWORD)(dwAddrBase + pExport->AddressOfNames);       // ��ȡ���Ʊ���RVA
	PWORD pEIT = (PWORD)(dwAddrBase + pExport->AddressOfNameOrdinals);  //��ȡ��������RVA

																		// 4����ȡGetProAddress�����ĵ�ַ
	for (DWORD i = 0; i < dwFunCount; i++)
	{
		if (!pEAT[i])
		{
			continue;
		}

		// 4.1 ��ȡ���
		DWORD dwID = pExport->Base + i;

		// 4.2 ����EIT ���л�ȡ�� GetProcAddress�ĵ�ַ
		for (DWORD dwIdx = 0; dwIdx < dwNameCount; dwIdx++)
		{
			// ��ű��е�Ԫ�ص�ֵ ��Ӧ�ź�����ַ����λ��
			if (pEIT[dwIdx] == i)
			{
				//������Ż�ȡ�����Ʊ��е�����
				DWORD dwNameOffset = pENT[dwIdx];
				char * pFunName = (char*)(dwAddrBase + dwNameOffset);

				//�ж��Ƿ���GetProcAddress����
				if (!strcmp(pFunName, "GetProcAddress"))
				{
					// ��ȡEAT�ĵ�ַ ����GetProcAddress��ַ����
					DWORD dwFunAddrOffset = pEAT[i];
					return dwAddrBase + dwFunAddrOffset;
				}
			}
		}
	}
	return -1;
}
//��ʼ��API
bool InitializationAPI()
{

	//��ʼ��
	g_funGetProcAddress = (LPGETPROCADDRESS)GetGPAFunAddr();
	g_funLoadLibraryEx = (LPLOADLIBRARYEX)g_funGetProcAddress((HMODULE)GetKernel32Base(), "LoadLibraryExW");
	hModuleKernel32 = g_funLoadLibraryEx(L"Kernel32.dll", NULL, NULL);
	hModuleUser32 = g_funLoadLibraryEx(L"user32.dll", NULL, NULL);
	g_funGetModuleHandle = (GETModuleHandle)g_funGetProcAddress(hModuleKernel32, "GetModuleHandleW");
	g_funMessageBox = (LPMESSAGEBOX)g_funGetProcAddress(hModuleUser32, "MessageBoxW");
	g_funCreateWindowEx = (CREateWindowEx)g_funGetProcAddress(hModuleUser32, "CreateWindowExW");
	g_funPostQuitMessage = (POSTQuitMessage)g_funGetProcAddress(hModuleUser32, "PostQuitMessage");
	g_funDefWindowProc = (DEFWindowProc)g_funGetProcAddress(hModuleUser32, "DefWindowProcW");
	g_funGetMessage = (GteMessage)g_funGetProcAddress(hModuleUser32, "GetMessageW");
	g_funRegisterClass = (REGisterClass)g_funGetProcAddress(hModuleUser32, "RegisterClassW");
	g_funShowWindow = (SHOWWINDOW)g_funGetProcAddress(hModuleUser32, "ShowWindow");
	g_funUpdateWindow = (UPDateWindow)g_funGetProcAddress(hModuleUser32, "UpdateWindow");
	g_funDispatchMessage = (DISpatchMessage)g_funGetProcAddress(hModuleUser32, "DispatchMessageW");
	g_funGetWindowText = (GETWindowText)g_funGetProcAddress(hModuleUser32, "GetWindowTextW");
	g_funGetWindowTextLength = (GETWindowTextLength)g_funGetProcAddress(hModuleUser32, "GetWindowTextLengthW");
	g_funGetDlgItem = (GETDlgItem)g_funGetProcAddress(hModuleUser32, "GetDlgItem");
	g_funSetWindowText = (SETWindowText)g_funGetProcAddress(hModuleUser32, "SetWindowTextW");
	g_funTranslateMessage = (TRanslateMessage)g_funGetProcAddress(hModuleUser32, "TranslateMessage");
	g_dwImageBase = (DWORD)g_funGetModuleHandle(NULL);
	g_oep = g_PackInfo.TargetOepRva + g_dwImageBase;
}
//�ж�����
int decide() {
	int a = 0;
	//wchar_t g_MIMA100[100] = L"haidragon"; // h68 a61 i69 d64   72	r  a61   67	g   6F	o   6E	n
	//wchar_t wStrtext[100] = L"����������";*/
	__asm
	{ 
push eax
push ebx
push ecx
push edi
push esi
////////////////////////////////////////////////////////////
            mov ecx ,18
		    mov edi,  offset g_MIMA100;//��������
		    mov esi,  offset g_wcbuf100
			repz cmpsb
			je  T
			jmp F
T:
		    mov a, 1
F:
////////////////////////////////////////////////////////////
		pop esi
		pop edi
		pop ecx
		pop ebx
		pop eax
	}
	return a;
}
void Decode()
{

	unsigned char * pBuf = (unsigned char *)0x00400000 + g_PackInfo.dwReloc;
	for (int i = 0; i < g_PackInfo.dwSize; i++)
	{
		pBuf[i] ^= 0x15;
	}
}
LRESULT CALLBACK WindowProc(
	_In_ HWND   hwnd,
	_In_ UINT   uMsg,
	_In_ WPARAM wParam,
	_In_ LPARAM lParam
) {


	switch (uMsg)
	{
	case WM_CREATE: {
		wchar_t wStr[20] = L"���ڻص���������";
		wchar_t wStr2[20] = L"haha";
		g_funMessageBox(NULL, wStr, wStr2, NULL);
		/////////////////////////////////////////////////////////////////////////////////////
		DWORD dwStyle = ES_LEFT | WS_CHILD | WS_OVERLAPPED | WS_VISIBLE;
		DWORD dwExStyle = WS_EX_CLIENTEDGE | WS_EX_LEFT | WS_EX_LTRREADING | WS_EX_RIGHTSCROLLBAR;
		HWND hWnd = g_funCreateWindowEx(
			dwExStyle, //dwExStyle ��չ��ʽ
			L"Edit", //lpClassName ��������
			wStrtext, //lpWindowName ���ڱ���
			dwStyle, //dwStyle ������ʽ
			150, //x ���λ��
			100, //y ����λ��
			200, //nWidth ����
			20, //nHeight �߶�
			hwnd, //hWndParent �����ھ��
			(HMENU)0x1002, //ID
			g_funGetModuleHandle(0), //hInstance Ӧ�ó�����
			NULL //lpParam ���Ӳ���
		);
		return 0;
		/////////////////////////////////////////////////////////////////////////////////
	}
	case WM_COMMAND: {
		WORD wId = LOWORD(wParam);
		WORD wCode = HIWORD(wParam);
		HANDLE hChild = (HANDLE)lParam;
		if (wId == 0x1001 && wCode == BN_CLICKED)
		{

			HWND hwndCombo = g_funGetDlgItem(hwnd, 0x1002);
			int cTxtLen = g_funGetWindowTextLength(hwndCombo);
			g_funGetWindowText(hwndCombo, g_wcbuf100, 100);

			wchar_t wStr[20] = L"��ť����";
			wchar_t wStr2[20] = L"haha";
			g_funMessageBox(NULL, wStr, wStr2, NULL);
			wchar_t wStr3[20] = L"";
			if (decide()==1) {
				//g_funPostQuitMessage(0);
				g_funShowWindow(hwnd, SW_HIDE);
				Decode();
				//_asm jmp g_PackInfo.TargetOep;
				_asm jmp g_oep;
				wchar_t wStr[20] = L"������ȷ������";
				wchar_t wStr2[20] = L"haha";
				g_funMessageBox(NULL, wStr, wStr2, NULL);
			}
			else {
				wchar_t wStr[20] = L"����������������룡����";
				wchar_t wStr2[20] = L"haha";
				g_funMessageBox(NULL, wStr, wStr2, NULL);
			}
			g_funSetWindowText(hwndCombo, wStr3);
			return 1;
		}
		break;
	}
	case WM_CLOSE:
	{
		g_funPostQuitMessage(0);
		//return 0;
		break;
	}

	}
	// ����Ĭ�ϵĴ��ڴ�������
	return g_funDefWindowProc(hwnd, uMsg, wParam, lParam);
}
void CtrateWin() {

	MSG msg = { 0 };
	wchar_t wStr[20] = L"allenboy";
	wchar_t wStr2[20] = L"haha";
	g_funMessageBox(NULL, wStr, wStr2, NULL);
	// ��ע�ᴰ����
	WNDCLASS wcs = {};
	wcs.lpszClassName = L"dragon";
	wcs.lpfnWndProc = WindowProc;
	wcs.hbrBackground = (HBRUSH)(COLOR_CAPTIONTEXT + 1);
	/////////////////////////////////////////////////////////////////////////////////////////
	//RegisterClass
	//RegisterClass(&wcs);
	g_funRegisterClass(&wcs);
	//#define CreateWindowW(lpClassName, lpWindowName, dwStyle, x, y,\
		//nWidth, nHeight, hWndParent, hMenu, hInstance, lpParam)
//ע�ᴰ��
//CreateWindowEx

//��������һ��Ҫ�������һ��
	HWND hWnd = g_funCreateWindowEx(0L, L"dragon", L"haidragon", WS_OVERLAPPEDWINDOW | WS_VISIBLE,
		500, 200, 500, 500,
		NULL, NULL, NULL, NULL);
	// ���ַ��  WS_OVERLAPPEDWINDOW  WS_POPUPWINDOW  WS_CHILDWINDOW

	g_funCreateWindowEx(0L, L"BUTTON", L"ok", WS_CHILD | WS_VISIBLE,
		200, 150,// �ڸ����ڵĿͻ�����λ�ã�
		100, 50,// �� ��
		hWnd,// ������
		(HMENU)0x1001,// ����Ƕ��㴰�� ���ǲ˵���� �Ӵ��ھ��Ǳ�����ID
					  //GetModuleHandle
		g_funGetModuleHandle(0), NULL);

	//ShowWindow(hWnd, SW_SHOW);
	g_funShowWindow(hWnd, SW_SHOW);
	g_funUpdateWindow(hWnd);
	/*while (GetMessage(&msg, 0, 0, 0))
	{
	DispatchMessage(&msg);
	}*/
	while (g_funGetMessage(&msg, 0, 0, 0))
	{

		//DispatchMessage(&msg);
		g_funTranslateMessage(&msg);
		g_funDispatchMessage(&msg);
	}
}


//������start()���� ���ڸ��Ƶ����ӵĽ�
_declspec(naked) void start()
{
	// ��ָ��
	_asm
	{
		PUSH - 1
		PUSH 0
		PUSH 0
		MOV EAX, DWORD PTR FS : [0]
		PUSH EAX
		MOV DWORD PTR FS : [0], ESP
		SUB ESP, 0x68
		PUSH EBX
		PUSH ESI
		PUSH EDI
		POP EAX
		POP EAX
		POP EAX
		ADD ESP, 0x68
		POP EAX
		MOV DWORD PTR FS : [0], EAX
		POP EAX
		POP EAX
		POP EAX
		POP EAX
		MOV EBP, EAX
	}
	InitializationAPI();
	CtrateWin();
	/*Decode();
	_asm jmp g_PackInfo.TargetOep;*/
}
