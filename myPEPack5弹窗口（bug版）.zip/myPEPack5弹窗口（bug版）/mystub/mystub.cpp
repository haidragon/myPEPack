// mystub.cpp : ���� DLL Ӧ�ó���ĵ���������
//
//CreateWindow         User32.dll
//GetModuleHandle      Kernel32.dll
//ShowWindow           User32.dll
//GetMessage           User32.dll
//RegisterClass        User32.dll
//DispatchMessage      User32.dll
//WindowProc    ֱ����
//PostQuitMessage      User32.dll
//DefWindowProc        User32.dll
//UpdateWindow         User32.dll
#include "stdafx.h"
#include "mystub.h"
//�ϲ���
#pragma comment(linker, "/merge:.data=.text") 
#pragma comment(linker, "/merge:.rdata=.text")
#pragma comment(linker, "/section:.text,RWE")
typedef int (WINAPI *LPMESSAGEBOX)(HWND, LPCTSTR, LPCTSTR, UINT); //MessageBoxW
typedef DWORD(WINAPI *LPGETPROCADDRESS)(HMODULE, LPCSTR);         // GetProcAddress
typedef HMODULE(WINAPI *LPLOADLIBRARYEX)(LPCTSTR, HANDLE, DWORD); // LoadLibaryEx
typedef HMODULE (WINAPI *GETModuleHandle)(
	_In_opt_ LPCTSTR lpModuleName
);
typedef BOOL (WINAPI* SHOWWINDOW)(
	_In_ HWND hWnd,
	_In_ int  nCmdShow
);
typedef BOOL (WINAPI* GteMessage)(
	_Out_    LPMSG lpMsg,
	_In_opt_ HWND  hWnd,
	_In_     UINT  wMsgFilterMin,
	_In_     UINT  wMsgFilterMax
);
typedef LRESULT (WINAPI* DISpatchMessage)(
	_In_ const MSG *lpmsg
);
typedef ATOM (WINAPI* REGisterClass)(
	_In_ const WNDCLASS *lpWndClass
);
typedef HWND (WINAPI *CREateWindowEx)(
	_In_     DWORD     dwExStyle,
	_In_opt_ LPCTSTR   lpClassName,
	_In_opt_ LPCTSTR   lpWindowName,
	_In_     DWORD     dwStyle,
	_In_     int       x,
	_In_     int       y,
	_In_     int       nWidth,
	_In_     int       nHeight,
	_In_opt_ HWND      hWndParent,
	_In_opt_ HMENU     hMenu,
	_In_opt_ HINSTANCE hInstance,
	_In_opt_ LPVOID    lpParam
);
typedef VOID (WINAPI* POSTQuitMessage)(
	_In_ int nExitCode
);
typedef LRESULT (WINAPI* DEFWindowProc)(
	_In_ HWND   hWnd,
	_In_ UINT   Msg,
	_In_ WPARAM wParam,
	_In_ LPARAM lParam
);
typedef BOOL(* UPDateWindow)(
	_In_ HWND hWnd
);
void start();
PACKINFO g_PackInfo = { (DWORD)start };
//��ȡkernel32ģ����ػ�ַ
DWORD GetKernel32Base()
{
	DWORD dwKernel32Addr = 0;
	__asm
	{
		push eax
		mov eax, dword ptr fs : [0x30] // eax = PEB�ĵ�ַ
		mov eax, [eax + 0x0C]          // eax = ָ��PEB_LDR_DATA�ṹ��ָ��
		mov eax, [eax + 0x1C]          // eax = ģ���ʼ��������ͷָ��InInitializationOrderModuleList
		mov eax, [eax]               // eax = �б��еĵڶ�����Ŀ
		mov eax, [eax + 0x08]          // eax = ��ȡ����Kernel32.dll��ַ��Win7�»�ȡ����KernelBase.dll�Ļ�ַ��
		mov dwKernel32Addr, eax
		pop eax
	}

	return dwKernel32Addr;
}
//��ȡGetProcAddress�Ļ�ַ
DWORD GetGPAFunAddr()
{
	DWORD dwAddrBase = GetKernel32Base();

	// 1. ��ȡDOSͷ��NTͷ
	PIMAGE_DOS_HEADER pDos_Header;
	PIMAGE_NT_HEADERS pNt_Header;
	pDos_Header = (PIMAGE_DOS_HEADER)dwAddrBase;
	pNt_Header = (PIMAGE_NT_HEADERS)(dwAddrBase + pDos_Header->e_lfanew);

	// 2. ��ȡ��������
	PIMAGE_DATA_DIRECTORY   pDataDir;
	PIMAGE_EXPORT_DIRECTORY pExport;
	pDataDir = pNt_Header->OptionalHeader.DataDirectory;
	pDataDir = &pDataDir[IMAGE_DIRECTORY_ENTRY_EXPORT];
	pExport = (PIMAGE_EXPORT_DIRECTORY)(dwAddrBase + pDataDir->VirtualAddress);

	// 3����ȡ�������ı�Ҫ��Ϣ
	DWORD dwModOffset = pExport->Name;                                  // ģ�������
	DWORD dwFunCount = pExport->NumberOfFunctions;                      // ��������������
	DWORD dwNameCount = pExport->NumberOfNames;                         // �������Ƶ�����

	PDWORD pEAT = (PDWORD)(dwAddrBase + pExport->AddressOfFunctions);   // ��ȡ��ַ����RVA
	PDWORD pENT = (PDWORD)(dwAddrBase + pExport->AddressOfNames);       // ��ȡ���Ʊ���RVA
	PWORD pEIT = (PWORD)(dwAddrBase + pExport->AddressOfNameOrdinals);  //��ȡ��������RVA

																		// 4����ȡGetProAddress�����ĵ�ַ
	for (DWORD i = 0; i < dwFunCount; i++)
	{
		if (!pEAT[i])
		{
			continue;
		}

		// 4.1 ��ȡ���
		DWORD dwID = pExport->Base + i;

		// 4.2 ����EIT ���л�ȡ�� GetProcAddress�ĵ�ַ
		for (DWORD dwIdx = 0; dwIdx < dwNameCount; dwIdx++)
		{
			// ��ű��е�Ԫ�ص�ֵ ��Ӧ�ź�����ַ����λ��
			if (pEIT[dwIdx] == i)
			{
				//������Ż�ȡ�����Ʊ��е�����
				DWORD dwNameOffset = pENT[dwIdx];
				char * pFunName = (char*)(dwAddrBase + dwNameOffset);

				//�ж��Ƿ���GetProcAddress����
				if (!strcmp(pFunName, "GetProcAddress"))
				{
					// ��ȡEAT�ĵ�ַ ����GetProcAddress��ַ����
					DWORD dwFunAddrOffset = pEAT[i];
					return dwAddrBase + dwFunAddrOffset;
				}
			}
		}
	}
	return -1;
}

LRESULT CALLBACK WindowProc(
	_In_ HWND   hwnd,
	_In_ UINT   uMsg,
	_In_ WPARAM wParam,
	_In_ LPARAM lParam
) {
	//��ʼ��
	LPGETPROCADDRESS g_funGetProcAddress = (LPGETPROCADDRESS)GetGPAFunAddr();
	LPLOADLIBRARYEX g_funLoadLibraryEx = (LPLOADLIBRARYEX)g_funGetProcAddress((HMODULE)GetKernel32Base(), "LoadLibraryExW");
	HMODULE hModuleKernel32 = g_funLoadLibraryEx(L"Kernel32.dll", NULL, NULL);
	HMODULE hModuleUser32 = g_funLoadLibraryEx(L"user32.dll", NULL, NULL);
	GETModuleHandle g_funGetModuleHandle = (GETModuleHandle)g_funGetProcAddress(hModuleKernel32, "GetModuleHandleW");
	
	switch (uMsg)
	{
	case WM_CREATE: {
		LPMESSAGEBOX g_funMessageBox = (LPMESSAGEBOX)g_funGetProcAddress(hModuleUser32, "MessageBoxW");
		wchar_t wStr[20] = L"���ڻص���������";
		wchar_t wStr2[20] = L"haha";
		g_funMessageBox(NULL, wStr, wStr2, NULL);
		DWORD dwStyle = ES_LEFT | WS_CHILD | WS_OVERLAPPED | WS_VISIBLE;
		DWORD dwExStyle = WS_EX_CLIENTEDGE | WS_EX_LEFT | WS_EX_LTRREADING | WS_EX_RIGHTSCROLLBAR;
		CREateWindowEx g_funCreateWindowEx = (CREateWindowEx)g_funGetProcAddress(hModuleUser32, "CreateWindowExW");
		HWND hWnd = g_funCreateWindowEx(
			dwExStyle, //dwExStyle ��չ��ʽ
			L"Edit", //lpClassName ��������
			L"text", //lpWindowName ���ڱ���
			dwStyle, //dwStyle ������ʽ
			150, //x ���λ��
			100, //y ����λ��
			200, //nWidth ����
			20, //nHeight �߶�
			hwnd, //hWndParent �����ھ��
			(HMENU)0x1002, //ID
			g_funGetModuleHandle(0), //hInstance Ӧ�ó�����
			NULL //lpParam ���Ӳ���
		);

		break;
	}
	case WM_CLOSE:
	{
		POSTQuitMessage g_funPostQuitMessage = (POSTQuitMessage)g_funGetProcAddress(hModuleUser32, "PostQuitMessage");
		g_funPostQuitMessage(0);
		break;
	}
	default:
		break;
	}
	// ����Ĭ�ϵĴ��ڴ�������
		
	DEFWindowProc g_funDefWindowProc = (DEFWindowProc)g_funGetProcAddress(hModuleUser32, "DefWindowProcW");

	return g_funDefWindowProc(hwnd, uMsg, wParam, lParam);
}
void CtrateWin() {

	MSG msg = { 0 };

	//��ʼ��
	LPGETPROCADDRESS g_funGetProcAddress = (LPGETPROCADDRESS)GetGPAFunAddr();
	LPLOADLIBRARYEX g_funLoadLibraryEx = (LPLOADLIBRARYEX)g_funGetProcAddress((HMODULE)GetKernel32Base(), "LoadLibraryExW");
	HMODULE hModuleUser32 = g_funLoadLibraryEx(L"user32.dll", NULL, NULL);
	LPMESSAGEBOX g_funMessageBox = (LPMESSAGEBOX)g_funGetProcAddress(hModuleUser32, "MessageBoxW");

	GteMessage g_funGetMessage = (GteMessage)g_funGetProcAddress(hModuleUser32, "GetMessageW");
	wchar_t wStr[20] = L"allenboy";
	wchar_t wStr2[20] = L"haha";
	g_funMessageBox(NULL, wStr, wStr2, NULL);
	// ��ע�ᴰ����
	WNDCLASS wcs = {};
	wcs.lpszClassName = L"dragon";
	wcs.lpfnWndProc = WindowProc;
	wcs.hbrBackground = (HBRUSH)(COLOR_CAPTIONTEXT + 1);
	/////////////////////////////////////////////////////////////////////////////////////////
	//RegisterClass
	REGisterClass g_funRegisterClass = (REGisterClass)g_funGetProcAddress(hModuleUser32, "RegisterClassW");
	//RegisterClass(&wcs);
	g_funRegisterClass(&wcs);
	HMODULE hModuleKernel32 = g_funLoadLibraryEx(L"Kernel32.dll", NULL, NULL);
	GETModuleHandle g_funGetModuleHandle = (GETModuleHandle)g_funGetProcAddress(hModuleKernel32, "GetModuleHandleW");
	//#define CreateWindowW(lpClassName, lpWindowName, dwStyle, x, y,\
	//nWidth, nHeight, hWndParent, hMenu, hInstance, lpParam)
//ע�ᴰ��
//CreateWindowEx
	
	CREateWindowEx g_funCreateWindowEx = (CREateWindowEx)g_funGetProcAddress(hModuleUser32, "CreateWindowExW");
	//��������һ��Ҫ�������һ��
	HWND hWnd = g_funCreateWindowEx(0L, L"dragon", L"haidragon", WS_OVERLAPPEDWINDOW | WS_VISIBLE,
		500, 200, 500, 500,
		NULL, NULL, NULL, NULL);
	// ���ַ��  WS_OVERLAPPEDWINDOW  WS_POPUPWINDOW  WS_CHILDWINDOW

	g_funCreateWindowEx(0L, L"BUTTON", L"��ť", WS_CHILD | WS_VISIBLE,
		200, 150,// �ڸ����ڵĿͻ�����λ�ã�
		100, 50,// �� ��
		hWnd,// ������
		(HMENU)0x1001,// ����Ƕ��㴰�� ���ǲ˵���� �Ӵ��ھ��Ǳ�����ID
					  //GetModuleHandle
		g_funGetModuleHandle(0), NULL);

	SHOWWINDOW g_funShowWindow = (SHOWWINDOW)g_funGetProcAddress(hModuleUser32, "ShowWindow");
	//ShowWindow(hWnd, SW_SHOW);
	g_funShowWindow(hWnd, SW_SHOW);
	UPDateWindow g_funUpdateWindow = (UPDateWindow)g_funGetProcAddress(hModuleUser32, "UpdateWindow");
	g_funUpdateWindow(hWnd);
	
																				 

	/*while (GetMessage(&msg, 0, 0, 0))
	{
	DispatchMessage(&msg);
	}*/
	while (g_funGetMessage(&msg, 0, 0, 0))
	{

		DISpatchMessage g_funDispatchMessage = (DISpatchMessage)g_funGetProcAddress(hModuleUser32, "DispatchMessageW");
		//DispatchMessage(&msg);
		g_funDispatchMessage(&msg);
	}
}
void Decode()
{
	
	unsigned char * pBuf = (unsigned char *)0x00400000 + g_PackInfo.dwReloc;
	for (int i = 0; i < g_PackInfo.dwSize; i++)
	{
		pBuf[i] ^= 0x15;
	}
}

//������start()���� ���ڸ��Ƶ����ӵĽ�
_declspec(naked) void start()
{
	CtrateWin();
	Decode();
	_asm jmp g_PackInfo.TargetOep;
}
