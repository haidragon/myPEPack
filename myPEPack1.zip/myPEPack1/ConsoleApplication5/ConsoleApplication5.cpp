// ConsoleApplication5.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include"PEpack.h"
#define PATH _T("E:\\allenboy.exe")

void Pack(TCHAR * Path)
{
	PEpack obj;
	obj.ReadFileToMem(Path);
	obj.AddSection((char*)"allen", (char*)"haha", 5, 0x1234);
	obj.SaveFile((TCHAR*)_T("E:\\allenboy_new.exe"));
}

int main()
{
	Pack((TCHAR*)PATH);
    return 0;
}

